// -----------------------------------------------------------------------------
// Copyright (C)  qbrobotics. All rights reserved.
// www.qbrobotics.com
// -----------------------------------------------------------------------------

/**
* \file 		utils.h
*
* \brief 		Declaration of utility functions.
* \date 		Dic. 1, 2015
* \author 		qbrobotics
* \copyright	(C)  qbrobotics. All rights reserved.
*/


#ifndef UTILS_H_INCLUDED
#define UTILS_H_INCLUDED

#include <globals.h>

//--------------------------------------------------------------     DEFINITIONS

#define ALPHA 3     ///< Voltage and current filters constants
#define BETA  50    ///< Emg filters constant
#define GAMMA 32 	///< Velocity filters constant
#define DELTA 32 	///< Acceleration filters constant

    
#define SIGN(A) (((A) >= 0) ? (1) : (-1))

//-------------------------------------------------------------     DECLARATIONS

int32 filter_i1(int32 value);
int32 filter_i2(int32 value);

int32 filter_vel_1(int32 value);
int32 filter_vel_2(int32 value);
int32 filter_vel_3(int32 value);

int32 filter_ch1(int32 value);
int32 filter_ch2(int32 value);

uint8 LCRChecksum(uint8 *data_array, const uint8 data_length);

CYBIT check_enc_data(const uint32*);
uint32 my_mod(int32 val, int32 divisor);

int calc_turns_fcn(const int32 pos1,const int32 pos2);

void calibration();

#endif

/* [] END OF FILE */