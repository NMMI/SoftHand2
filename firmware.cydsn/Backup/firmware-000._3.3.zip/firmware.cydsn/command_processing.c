// ----------------------------------------------------------------------------
// Copyright (C)  qbrobotics. All rights reserved.
// www.qbrobotics.com
// ----------------------------------------------------------------------------


/**
* \file         command_processing.c
*

* \brief        Command processing functions.
* \date         Dic. 1, 2015
* \author       qbrobotics
* \copyright    (C)  qbrobotics. All rights reserved.
*/

//=================================================================     includes
#include <command_processing.h>
#include <stdio.h>
#include <interruptions.h>

#include "commands.h"
#include "utils.h"

//================================================================     variables

reg8 * EEPROM_ADDR = (reg8 *) CYDEV_EE_BASE;

//==============================================================================
//                                                            RX DATA PROCESSING
//==============================================================================
//  This function checks for the availability of a data packet and process it:
//      - Verify checksum;
//      - Process commands;
//==============================================================================

void commProcess(){
    
    uint8 CYDATA rx_cmd;

    rx_cmd = g_rx.buffer[0];

//==========================================================     verify checksum

    if (!(LCRChecksum(g_rx.buffer, g_rx.length - 1) == g_rx.buffer[g_rx.length - 1])){
        // Wrong checksum
        g_rx.ready = 0;
        return;
    }

    switch(rx_cmd){
//=====================================================     CMD_GET_MEASUREMENTS

        case CMD_GET_MEASUREMENTS:
            cmd_get_measurements();
            break;
            
//============================================================     CMD_GET_INPUT

        case CMD_GET_INPUTS:
            cmd_get_inputs();
            break;
//=========================================================     CMD_GET_CURRENTS

        case CMD_GET_CURRENTS:
            cmd_get_currents();
            break;

//====================================================     CMD_GET_CURR_AND_MEAS

        case CMD_GET_CURR_AND_MEAS:
            cmd_get_curr_and_meas();
            break;
            
//===========================================================     CMD_SET_INPUTS

        case CMD_SET_INPUTS:
            cmd_set_inputs();
            break;
            
//========================================================     CMD_SET_POS_STIFF

        case CMD_SET_POS_STIFF:
            cmd_set_pos_stiff();
            break;
            
//=======================================================     CMD_GET_VELOCITIES

        case CMD_GET_VELOCITIES:
            cmd_get_velocities();
            break;

//=============================================================     CMD_ACTIVATE
        case CMD_ACTIVATE:
            cmd_activate();
            break;
            
//=============================================================     CMD_WATCHDOG
            
        case CMD_SET_WATCHDOG:
            cmd_set_watchdog();
            break;
            
//=========================================================     CMD_GET_ACTIVATE
            
        case CMD_GET_ACTIVATE:
            cmd_get_activate();
            break;
            
//=========================================================     CMD_SET_BAUDRATE
            
        case CMD_SET_BAUDRATE:
            cmd_set_baudrate();
            break;  
            
//=============================================================     CMD_GET_INFO
            
        case CMD_GET_INFO:
            infoGet( *((uint16 *) &g_rx.buffer[1]));
            break;

//============================================================     CMD_SET_PARAM
            
        case CMD_SET_PARAM:
            paramSet( *((uint16 *) &g_rx.buffer[1]) );
            break;

//============================================================     CMD_GET_PARAM
            
        case CMD_GET_PARAM:
            paramGet( *((uint16 *) &g_rx.buffer[1]) );
            break;

//=================================================================     CMD_PING
            
        case CMD_PING:
            cmd_ping();
            break;

//=========================================================     CMD_STORE_PARAMS
            
        case CMD_STORE_PARAMS:
            cmd_store_params();
            break;

//=================================================     CMD_STORE_DEFAULT_PARAMS
            
        case CMD_STORE_DEFAULT_PARAMS:
            if ( memStore(DEFAULT_EEPROM_DISPLACEMENT) ) {
                sendAcknowledgment(ACK_OK);
            } else {
                sendAcknowledgment(ACK_ERROR);
            }
            break;

//=======================================================     CMD_RESTORE_PARAMS

        case CMD_RESTORE_PARAMS:
            if ( memRestore() ) {
                sendAcknowledgment(ACK_OK);
            } else {
                sendAcknowledgment(ACK_ERROR);
            }
            break;

//=============================================================     CMD_INIT_MEM

        case CMD_INIT_MEM:
            if ( memInit() ) {
                sendAcknowledgment(ACK_OK);
            } else {
                sendAcknowledgment(ACK_ERROR);
            }
            break;

//===========================================================     CMD_BOOTLOADER
        case CMD_BOOTLOADER:
            sendAcknowledgment(ACK_OK);
            CyDelay(1000);
            FTDI_ENABLE_REG_Write(0x00);
            CyDelay(1000);
            Bootloadable_Load();
            break;

//============================================================     CMD_CALIBRATE
        case CMD_CALIBRATE:
            calibration_flag = START;
            sendAcknowledgment(ACK_OK);
            break;
    }

    g_rx.ready = 0;
}

//==============================================================================
//                                                              COMMAND GET INFO
//==============================================================================

void infoGet(uint16 info_type){
    unsigned char packet_string[1100];

//======================================     choose info type and prepare string

    switch (info_type) {
        case INFO_ALL:
            infoPrepare(packet_string);
            UART_RS485_PutString(packet_string);
            break;
        default:
            break;
    }
}

//==============================================================================
//                                                        COMMAND SET PARAMETER
//==============================================================================

void paramSet(uint16 param_type)
{
    uint8 CYDATA i;

    switch(param_type)
    {
        //-----------------------------------------------------------     Set Id
        case PARAM_ID:
            g_mem.id = g_rx.buffer[3];
            break;

        //----------------------------------------------------     Set PID Param
        case PARAM_PID_CONTROL:
            g_mem.k_p = *((double *) &g_rx.buffer[3]) * 65536;
            g_mem.k_i = *((double *) &g_rx.buffer[3 + 4]) * 65536;
            g_mem.k_d = *((double *) &g_rx.buffer[3 + 8]) * 65536;
            break;

        //-----------------------------------------------     Set Curr PID Param
        case PARAM_PID_CURR_CONTROL:
            g_mem.k_p_c = *((double *) &g_rx.buffer[3]) * 65536;
            g_mem.k_i_c = *((double *) &g_rx.buffer[3 + 4]) * 65536;
            g_mem.k_d_c = *((double *) &g_rx.buffer[3 + 8]) * 65536;
            break;

        //--------------------------------------     Set Startup Activation Flag
        case PARAM_STARTUP_ACTIVATION:
            g_mem.activ = g_rx.buffer[3];
            break;

        //---------------------------------------------------     Set Input Mode
        case PARAM_INPUT_MODE:
            g_mem.input_mode = g_rx.buffer[3];
            break;

        //-------------------------------------------------     Set Control Mode
        case PARAM_CONTROL_MODE:
            g_mem.control_mode = g_rx.buffer[3];
            break;

        //---------------------------------------------------     Set Resolution
        case PARAM_POS_RESOLUTION:
            for (i =0; i < NUM_OF_SENSORS; ++i) 
                g_mem.res[i] = g_rx.buffer[i + 3];
            
            break;

        //------------------------------------------------------     Set Offsets
        case PARAM_MEASUREMENT_OFFSET:
            for(i = 0; i < NUM_OF_SENSORS; ++i)
            {
                g_mem.m_off[i] = *((int16 *) &g_rx.buffer[3 + i * 2]);
                g_mem.m_off[i] = g_mem.m_off[i] << g_mem.res[i];

                g_meas.rot[i] = 0;
            }
            reset_last_value_flag = 1;
            break;

        //--------------------------------------------------     Set Multipliers
        case PARAM_MEASUREMENT_MULTIPLIER:
            for(i = 0; i < NUM_OF_SENSORS; ++i)
            {
                g_mem.m_mult[i] =
                    *((double *) &g_rx.buffer[3 + i * 4]);
            }
            break;

        //------------------------------------------     Set Position Limit Flag
        case PARAM_POS_LIMIT_FLAG:
            g_mem.pos_lim_flag = *((uint8 *) &g_rx.buffer[3]);
            break;

        //-----------------------------------------------     Set Position Limit
        case PARAM_POS_LIMIT:
            for (i = 0; i < NUM_OF_MOTORS; i++) {
                g_mem.pos_lim_inf[i] = *((int16 *) &g_rx.buffer[3 + (i * 4)]);
                g_mem.pos_lim_sup[i] = *((int16 *) &g_rx.buffer[3 + (i * 4) + 2]);

                g_mem.pos_lim_inf[i] = g_mem.pos_lim_inf[i] << g_mem.res[i];
                g_mem.pos_lim_sup[i] = g_mem.pos_lim_sup[i] << g_mem.res[i];

            }
            break;

        //------------------------------------------------     Set Current Limit
        case PARAM_CURRENT_LIMIT:
            g_mem.current_limit = *((int16*) &g_rx.buffer[3]);
            break;

    }
    sendAcknowledgment(ACK_OK);
}

//==============================================================================
//                                                         COMMAND GET PARAMETER
//==============================================================================

void paramGet(uint16 param_type)
{
    uint8 packet_data[20];
    uint16 packet_lenght;
    uint8 i;

    packet_data[0] = CMD_GET_PARAM;

    switch(param_type)
    {
        //-----------------------------------------------------------     Get Id
        case PARAM_ID:
            packet_data[1] = c_mem.id;
            packet_lenght = 3;
            break;

        //----------------------------------------------------     Get PID Param
        case PARAM_PID_CONTROL:
            *((double *) (packet_data + 1)) = (double) c_mem.k_p / 65536;
            *((double *) (packet_data + 5)) = (double) c_mem.k_i / 65536;
            *((double *) (packet_data + 9)) = (double) c_mem.k_d / 65536;
            packet_lenght = 14;
            break;

        //-----------------------------------------------     Get Curr PID Param
        case PARAM_PID_CURR_CONTROL:
            *((double *) (packet_data + 1)) = (double) c_mem.k_p_c / 65536;
            *((double *) (packet_data + 5)) = (double) c_mem.k_i_c / 65536;
            *((double *) (packet_data + 9)) = (double) c_mem.k_d_c / 65536;
            packet_lenght = 14;
            break;

        //--------------------------------------     Get Startup Activation Flag
        case PARAM_STARTUP_ACTIVATION:
            packet_data[1] = c_mem.activ;
            packet_lenght = 3;
            break;

        //---------------------------------------------------     Get Input Mode
        case PARAM_INPUT_MODE:
            packet_data[1] = c_mem.input_mode;
            packet_lenght = 3;
            break;

        //-------------------------------------------------     Get Control Mode
        case PARAM_CONTROL_MODE:
            packet_data[1] = c_mem.control_mode;
            packet_lenght = 3;
            break;

        //---------------------------------------------------     Get Resolution
        case PARAM_POS_RESOLUTION:
            for (i = 0; i < NUM_OF_SENSORS; i++) {
                packet_data[i+1] = c_mem.res[i];
            }
            packet_lenght = NUM_OF_SENSORS + 2;
            break;

        //------------------------------------------------------     Get Offsets
        case PARAM_MEASUREMENT_OFFSET:
            for(i = 0; i < NUM_OF_SENSORS; ++i)
            {
                *((int16 *) ( packet_data + 1 + (i * 2) )) = (int16) (c_mem.m_off[i] >> c_mem.res[i]);

            }

            packet_lenght = 2 + NUM_OF_SENSORS * 2;
            break;

        //--------------------------------------------------     Get Multipliers
        case PARAM_MEASUREMENT_MULTIPLIER:
            for(i = 0; i < NUM_OF_SENSORS; ++i)
            {
                *((double *) ( packet_data + 1 + (i * 4) )) =
                    c_mem.m_mult[i];
            }

            packet_lenght = 2 + NUM_OF_SENSORS * 4;
            break;

        //------------------------------------------     Get Position Limit Flag
        case PARAM_POS_LIMIT_FLAG:
            packet_data[1] = c_mem.pos_lim_flag;
            packet_lenght = 3;
            break;

        //-----------------------------------------------     Get Position Limit
        case PARAM_POS_LIMIT:
            for (i = 0; i < NUM_OF_MOTORS; i++) {
                *((int32 *)( packet_data + 1 + (i * 2 * 4) )) =
                    c_mem.pos_lim_inf[i];
                *((int32 *)( packet_data + 1 + (i * 2 * 4) + 4)) =
                    c_mem.pos_lim_sup[i];
            }
            packet_lenght = 2 + (NUM_OF_MOTORS * 2 * 4);
            break;

        //------------------------------------------------     Get Current Limit
        case PARAM_CURRENT_LIMIT:
            *((int16 *)(packet_data + 1)) = c_mem.current_limit;
            packet_lenght = 4;
            break;

    }

    packet_data[packet_lenght - 1] = LCRChecksum(packet_data,packet_lenght - 1);
    commWrite(packet_data, packet_lenght);

}

//==============================================================================
//                                                           PREPARE DEVICE INFO
//==============================================================================

void infoPrepare(unsigned char *info_string)
{
    int CYDATA i;

    unsigned char str[50];
    
    strcpy(info_string, "");
    strcat(info_string, "\r\n");
    strcat(info_string, "Firmware version: ");
    strcat(info_string, VERSION);
    strcat(info_string, ".\r\n\r\n");

    strcat(info_string,"DEVICE INFO\r\n");
    sprintf(str,"ID: %d\r\n",(int) c_mem.id);
    strcat(info_string,str);
    sprintf(str,"Number of sensors: %d\r\n",(int) NUM_OF_SENSORS);
    strcat(info_string,str);
    sprintf(str,"PWM Limit: %d\r\n",(int) dev_pwm_limit);
    strcat(info_string,str);
    strcat(info_string,"\r\n");

    strcat(info_string, "MOTOR INFO\r\n");
    strcat(info_string, "Motor references: ");
    
    for (i = 0; i < NUM_OF_MOTORS; i++) {
        sprintf(str, "%d ", (int)(g_refOld.pos[i] >> c_mem.res[i]));
        strcat(info_string,str);
    }
    strcat(info_string,"\r\n");

    sprintf(str, "Motor enabled: ");
    
    if (g_refOld.onoff & 0x03) {
        strcat(str,"YES\r\n");
    } else {
        strcat(str,"NO\r\n");
    }
    strcat(info_string, str);


    strcat(info_string,"\r\nMEASUREMENTS INFO\r\n");
    strcat(info_string, "Sensor value:\r\n");
    for (i = 0; i < NUM_OF_SENSORS; i++) {
        sprintf(str,"%d -> %d", i+1,
            (int)(g_measOld.pos[i] >> c_mem.res[i]));
        strcat(info_string, str);
        strcat(info_string, "\r\n");
    }
    sprintf(str,"Voltage (mV): %ld", (int32) dev_tension );
    strcat(info_string, str);
    strcat(info_string,"\r\n");

    sprintf(str,"Current 1 (mA): %ld", (int32) g_measOld.curr[0] );
    strcat(info_string, str);
    strcat(info_string,"\r\n");

    sprintf(str,"Current 2 (mA): %ld", (int32) g_measOld.curr[1] );
    strcat(info_string, str);
    strcat(info_string,"\r\n");


    strcat(info_string, "\r\nDEVICE PARAMETERS\r\n");

    strcat(info_string, "PID Controller:\r\n");
    sprintf(str,"P -> %f\r\n", ((double) c_mem.k_p / 65536));
    strcat(info_string, str);
    sprintf(str,"I -> %f\r\n", ((double) c_mem.k_i / 65536));
    strcat(info_string, str);
    sprintf(str,"D -> %f\r\n", ((double) c_mem.k_d / 65536));
    strcat(info_string, str);

    strcat(info_string, "Current PID Controller:\r\n");
    sprintf(str,"P -> %f\r\n", ((double) c_mem.k_p_c / 65536));
    strcat(info_string, str);
    sprintf(str,"I -> %f\r\n", ((double) c_mem.k_i_c / 65536));
    strcat(info_string, str);
    sprintf(str,"D -> %f\r\n", ((double) c_mem.k_d_c / 65536));
    strcat(info_string, str);

    strcat(info_string,"\r\n");

    if (c_mem.activ == 0x03) {
        strcat(info_string, "Startup activation: YES\r\n");
    } else {
        strcat(info_string, "Startup activation: NO\r\n");
    }

    switch(c_mem.input_mode) {
        case 0:
            strcat(info_string, "Input mode: USB\r\n");
            break;
        case 1:
            strcat(info_string, "Input mode: Sensor 3\r\n");
            break;
    }

    strcat(info_string, "Control Mode: ");
    switch(c_mem.control_mode) {
        case CONTROL_ANGLE:
            strcat(info_string, "Position\r\n");
            break;
        case CONTROL_PWM:
            strcat(info_string, "PWM\r\n");
            break;
        case CONTROL_CURRENT:
            strcat(info_string, "Current\r\n");
            break;
        case CURR_AND_POS_CONTROL:
            strcat(info_string, "Current and position\r\n");
            break;
    }



    strcat(info_string, "Sensor resolution:\r\n");
    for(i = 0; i < NUM_OF_SENSORS; ++i)
    {
        sprintf(str,"%d -> %d", (int) (i + 1),
            (int) c_mem.res[i]);
        strcat(info_string, str);
        strcat(info_string,"\r\n");
    }


    strcat(info_string, "Measurement Offset:\r\n");
    for(i = 0; i < NUM_OF_SENSORS; ++i)
    {
        sprintf(str,"%d -> %ld", (int) (i + 1),
            (int32) c_mem.m_off[i] >> c_mem.res[i]);
        strcat(info_string, str);
        strcat(info_string,"\r\n");
    }

    strcat(info_string, "Measurement Multiplier:\r\n");
    for(i = 0; i < NUM_OF_SENSORS; ++i)
    {
        sprintf(str,"%d -> %f", (int)(i + 1),
            (double) c_mem.m_mult[i]);
        strcat(info_string, str);
        strcat(info_string,"\r\n");
    }

    sprintf(str, "Position limit active: %d", (int)g_mem.pos_lim_flag);
    strcat(info_string, str);
    strcat(info_string,"\r\n");

    for (i = 0; i < NUM_OF_MOTORS; i++) {
        sprintf(str, "Position limit motor %d: inf -> %ld  ", (int)(i + 1),
                (int32)g_mem.pos_lim_inf[i] >> g_mem.res[i]);
        strcat(info_string, str);

        sprintf(str, "sup -> %ld\r\n",
                (int32)g_mem.pos_lim_sup[i] >> g_mem.res[i]);
        strcat(info_string, str);
    }

    sprintf(str, "Max stiffness: %d", (int)g_mem.max_stiffness >> g_mem.res[0]);
    strcat(info_string, str);
    strcat(info_string,"\r\n");

    sprintf(str, "Current limit: %d", (int)g_mem.current_limit);
    strcat(info_string, str);
    strcat(info_string,"\r\n");
    
    sprintf(str, "debug: %ld", (uint32) timer_value0 - (uint32) timer_value);
    strcat(info_string, str);
    strcat(info_string, "\r\n");
}

//==============================================================================
//                                                      WRITE FUNCTION FOR RS485
//==============================================================================

void commWrite(uint8 *packet_data, const uint8 packet_lenght)
{
    uint16 CYDATA index;

    // frame - start
    UART_RS485_PutChar(':');
    UART_RS485_PutChar(':');
    
    // frame - ID
    UART_RS485_PutChar(g_mem.id);
    
    // frame - length
    UART_RS485_PutChar(packet_lenght);
    
    // frame - packet data
    for(index = 0; index < packet_lenght; ++index)
        UART_RS485_PutChar(packet_data[index]);
    
    index = 0;

    while(!(UART_RS485_ReadTxStatus() & UART_RS485_TX_STS_COMPLETE) && index++ <= 1000){}

    RS485_CTS_Write(1);
    RS485_CTS_Write(0);
}

//==============================================================================
//                                                       ACKNOWLEDGMENT FUNCTION
//==============================================================================

void sendAcknowledgment(const uint8 value) {

    // Packet: header + crc
    
    uint8 CYDATA packet_data[2];

    // Header
    packet_data[0] = value;
    
    // Payload/CRC
    packet_data[1] = value;

    commWrite(packet_data, 2);
}

//==============================================================================
//                                                                  STORE MEMORY
//==============================================================================
/**
* This function stores current memory settings on the eeprom with the specified
* displacement
**/

uint8 memStore(int displacement) {

    uint8 writeStatus;
    int i;
    int pages;
    uint8 ret_val = 1;

    PWM_MOTORS_WriteCompare1(0);
    PWM_MOTORS_WriteCompare2(0);

    // Retrieve temperature for better writing performance
    EEPROM_UpdateTemperature();

    memcpy( &c_mem, &g_mem, sizeof(g_mem) );

    pages = sizeof(g_mem) / 16 + (sizeof(g_mem) % 16 > 0);

    for(i = 0; i < pages; ++i) {
        writeStatus = EEPROM_Write(&g_mem.flag + 16 * i, i + displacement);
        if(writeStatus != CYRET_SUCCESS) {
            ret_val = 0;
            break;
        }
    }

    memcpy( &g_mem, &c_mem, sizeof(g_mem) );

    return ret_val;
}


//==============================================================================
//                                                                 RECALL MEMORY
//==============================================================================
/**
* This function loads user settings from the eeprom.
**/

void memRecall(void) {

    uint16 i;

    for (i = 0; i < sizeof(g_mem); i++) 
        ((reg8 *) &g_mem.flag)[i] = EEPROM_ADDR[i];
   

    //check for initialization
    if (g_mem.flag == FALSE) 
        memRestore();
    else 
        memcpy( &c_mem, &g_mem, sizeof(g_mem) );
    
}


//==============================================================================
//                                                                RESTORE MEMORY
//==============================================================================
/**
* This function loads default settings from the eeprom.
**/

uint8 memRestore(void) {

    uint16 i;

    for (i = 0; i < sizeof(g_mem); i++) 
        ((reg8 *) &g_mem.flag)[i] = EEPROM_ADDR[i + (DEFAULT_EEPROM_DISPLACEMENT * 16)];
    

    //check for initialization
    if (g_mem.flag == FALSE) 
        return memInit();
     else 
        return memStore(0);
   
}

//==============================================================================
//                                                                   MEMORY INIT
//==============================================================================
/**
* This function initialize memory when eeprom is compromised.
**/

uint8 memInit(void) {

    uint8 CYDATA i;
    //initialize memory settings
    g_mem.id                =   1;
    g_mem.k_p               =   0.1 * 65536;
    g_mem.k_i               =   0 * 65536;
    g_mem.k_d               =   0.8 * 65536;
    g_mem.k_p_c             =   5 * 65536;
    g_mem.k_i_c             =   0 * 65536;
    g_mem.k_d_c             =   0.8 * 65536;
    g_mem.activ             =   0;
    g_mem.input_mode        =   0;
    g_mem.control_mode      =   0;
    g_mem.watchdog_period   =   MAX_WATCHDOG_TIMER;

    g_mem.pos_lim_flag = 1;

    for (i = 0; i < NUM_OF_MOTORS; i++) {
        g_mem.pos_lim_inf[i] = -30000;
        g_mem.pos_lim_sup[i] =  30000;
    }

    for(i = 0; i < NUM_OF_SENSORS; ++i)
    {
        g_mem.m_mult[i] = 1;
        g_mem.res[i] = 1;
    }

    g_mem.m_off[0] = (int32)0 << g_mem.res[0];
    g_mem.m_off[1] = (int32)0 << g_mem.res[1];
    g_mem.m_off[2] = (int32)0 << g_mem.res[2];

    g_mem.max_stiffness = (int32)3000 << g_mem.res[0];

    g_mem.current_limit = DEFAULT_CURRENT_LIMIT;

    //set the initialized flag to show EEPROM has been populated
    g_mem.flag = TRUE;

    //write that configuration to EEPROM
    return ( memStore(0) && memStore(DEFAULT_EEPROM_DISPLACEMENT) );
}

//==============================================================================
//                                                    ROUTINE INTERRUPT FUNCTION
//==============================================================================
/**
* Bunch of functions used on request from UART communication
**/

void cmd_get_measurements(){
   
    
    uint8 CYDATA index;
   
    // Packet: header + measure(int16) + crc
    
    #if (NUM_OF_SENSORS == 4)
        uint8 packet_data[10];
    #endif
    #if  (NUM_OF_SENSORS == 3)
        uint8 packet_data[8]; 
    #endif

    //Header package
    packet_data[0] = CMD_GET_MEASUREMENTS;   
    
    for (index = NUM_OF_SENSORS; index--;) 
        *((int16 *) &packet_data[(index << 1) + 1]) = (int16)(g_measOld.pos[index] >> g_mem.res[index]);
            
    // Calculate Checksum and send message to UART 
        
    #if (NUM_OF_SENSORS == 4)
        packet_data[9] = LCRChecksum (packet_data, 9);
        commWrite(packet_data, 10);
    #endif
    #if  (NUM_OF_SENSORS == 3)
        packet_data[7] = LCRChecksum (packet_data, 7);
        commWrite(packet_data, 8);
    #endif
    
}

void cmd_get_inputs(){

    // Packet: header + motor_measure(int16) + crc

    uint8 packet_data[6]; 
    
    //Header package

    packet_data[0] = CMD_GET_INPUTS;
    
    *((int16 *) &packet_data[1]) = (int16) (g_refOld.pos[0]  >> g_mem.res[0]);
    *((int16 *) &packet_data[3]) = (int16) (g_refOld.pos[1]  >> g_mem.res[1]);
    
    // Calculate Checksum and send message to UART 

    packet_data[5] = LCRChecksum(packet_data, 5);

    commWrite(packet_data, 6);

}

void cmd_get_currents(){
    
    // Packet: header + motor_measure(int16) + crc
    
    uint8 packet_data[6]; 
    
    //Header package

    packet_data[0] = CMD_GET_CURRENTS;

    *((int16 *) &packet_data[1]) = (int16) g_measOld.curr[0];
    *((int16 *) &packet_data[3]) = (int16) g_measOld.curr[1];

    // Calculate Checksum and send message to UART 

    packet_data[5] = LCRChecksum (packet_data, 5);

    commWrite(packet_data, 6);
}

void cmd_get_curr_and_meas(){
    
    uint8 CYDATA index;
   
    //Packet: header + curr_meas(int16) + pos_meas(int16) + CRC
    
    #if (NUM_OF_SENSORS == 4)
        uint8 packet_data[14];
    #endif
    #if  (NUM_OF_SENSORS == 3)
        uint8 packet_data[12]; 
    #endif

    //Header package
    packet_data[0] = CMD_GET_CURR_AND_MEAS;
    
    // Currents
    *((int16 *) &packet_data[1]) = (int16) g_measOld.curr[0];
    *((int16 *) &packet_data[3]) = (int16) g_measOld.curr[1];

    // Positions
    for (index = NUM_OF_SENSORS; index--;) 
        *((int16 *) &packet_data[(index << 2) + 5]) = (int16) (g_measOld.pos[index] >> g_mem.res[index]);
        
    // Calculate Checksum and send message to UART 
        
    #if (NUM_OF_SENSORS == 4)
        packet_data[13] = LCRChecksum (packet_data, 13);
        commWrite(packet_data, 14);
    #endif
    #if  (NUM_OF_SENSORS == 3)
        packet_data[11] = LCRChecksum (packet_data, 11);
        commWrite(packet_data, 12);
    #endif
}

void cmd_set_inputs(){
    
    // Store position setted in right variables
    g_refNew.pos[0] = *((int16 *) &g_rx.buffer[1]);   // motor 1
    g_refNew.pos[0] = g_refNew.pos[0] << g_mem.res[0];

    g_refNew.pos[1] = *((int16 *) &g_rx.buffer[3]);   // motor 2
    g_refNew.pos[1] = g_refNew.pos[1] << g_mem.res[1];

    // Check Position Limit cmd
    if (c_mem.pos_lim_flag) {                      
        
        if (g_refNew.pos[0] < c_mem.pos_lim_inf[0]) 
            g_refNew.pos[0] = c_mem.pos_lim_inf[0];
        if (g_refNew.pos[1] < c_mem.pos_lim_inf[1]) 
            g_refNew.pos[1] = c_mem.pos_lim_inf[1];

        if (g_refNew.pos[0] > c_mem.pos_lim_sup[0]) 
            g_refNew.pos[0] = c_mem.pos_lim_sup[0];
        if (g_refNew.pos[1] > c_mem.pos_lim_sup[1]) 
            g_refNew.pos[1] = c_mem.pos_lim_sup[1];
    }
}

void cmd_set_pos_stiff(){
    
    int32 CYDATA pos, stiff;
    
    // Load position e stiffness

    pos = *((int16 *) &g_rx.buffer[1]);      // equilibrium position
    stiff = *((int16 *) &g_rx.buffer[3]);    // stiffness

    // Convert position in ticks
    pos = pos << g_mem.res[0];

    // Check position limits
    if (pos > (c_mem.pos_lim_sup[0] - c_mem.max_stiffness))
        pos = c_mem.pos_lim_sup[0] - c_mem.max_stiffness;

    if (pos < (c_mem.pos_lim_inf[0] + c_mem.max_stiffness))
        pos = c_mem.pos_lim_inf[0] + c_mem.max_stiffness;

    // Stiffness is intended between -32768 and 32767
    // remap  stiff value between -MAX_STIFFNESS and MAX_STIFFNESS
        
    stiff = (int32)(((float) c_mem.max_stiffness / 32768.0) * stiff);

    // Store pos/stiff rule
    g_refNew.pos[0] = pos + stiff;
    g_refNew.pos[1] = pos - stiff;
}

void cmd_get_velocities(){
    
    uint8 CYDATA index;
    
    // Packet: header + measure(int16) + crc

    #if (NUM_OF_SENSORS == 4)
        uint8 packet_data[10];
    #endif
    #if (NUM_OF_SENSORS == 3)
        uint8 packet_data[8]; 
    #endif
    
    //Header package
  
    packet_data[0] = CMD_GET_VELOCITIES;   
   
    for (index = NUM_OF_SENSORS; index--;)
        *((int16 *) &packet_data[(index << 2) + 1]) = (int16)(g_measOld.vel[index]);

    // Calculate Checksum and send message to UART 

    #if (NUM_OF_SENSORS == 4)
        packet_data[9] = LCRChecksum (packet_data, 9);
        commWrite(packet_data, 10);
    #endif
    #if  (NUM_OF_SENSORS == 3)
        packet_data[7] = LCRChecksum (packet_data, 7);
        commWrite(packet_data, 8);
    #endif
}

void cmd_activate(){
    
    // Store new value reads
    g_refNew.onoff = g_rx.buffer[1];
    
    // Check type of control mode enabled
    if (g_mem.control_mode == CONTROL_ANGLE) {
        g_refNew.pos[0] = g_meas.pos[0];
        g_refNew.pos[1] = g_meas.pos[1];
    }
    
    // Safety start position (eliminate "lost rotation" problem)    
    if((g_meas.pos[0] > 26000) || (g_meas.pos[0] < -26000) || 
       (g_meas.pos[1] > 26000) || (g_meas.pos[1] < -26000) ||
       (g_meas.pos[2] > 26000) || (g_meas.pos[2] < -26000))
        g_refNew.onoff = 0x00;
    
    // Activate/Disactivate motors
    MOTOR_ON_OFF_Write(g_refNew.onoff);

}

void cmd_set_watchdog(){
      
    if (g_rx.buffer[1] <= 0){
        // Deactivate Watchdog
        WATCHDOG_ENABLER_Write(1); 
        g_mem.watchdog_period = 0;   
    }
    else{
        // Activate Watchdog        
        if (g_rx.buffer[1] > MAX_WATCHDOG_TIMER)
            g_rx.buffer[1] = MAX_WATCHDOG_TIMER;
            
        // Period * Time_CLK = WDT
        // Period = WTD / Time_CLK =     (WTD    )  / ( ( 1 / Freq_CLK ) )
        // Set request watchdog period - (WTD * 2)  * (250 / 1024        )
        g_mem.watchdog_period = (uint8) (((uint32) g_rx.buffer[1] * 2 * 250 ) >> 10);   
        WATCHDOG_COUNTER_WritePeriod(g_mem.watchdog_period); 
        WATCHDOG_ENABLER_Write(0); 
    }
}

void cmd_get_activate(){
    
    uint8 packet_data[3];

    // Header        
    packet_data[0] = CMD_GET_ACTIVATE;
    
    // Fill payload
    packet_data[1] = g_ref.onoff;
    
    // Calculate checksum
    packet_data[2] = LCRChecksum(packet_data, 2);
    
    // Send package to UART
    commWrite(packet_data, 3);

}

void cmd_ping(){

    uint8 packet_data[2];

    // Header
    packet_data[0] = CMD_PING;
    
    // Load Payload
    packet_data[1] = CMD_PING;

    // Send Package to uart
    commWrite(packet_data, 2);
}

void cmd_store_params(){
        
    // Check input mode enabled
    
    if( c_mem.input_mode == INPUT_MODE_EXTERNAL ){
    
        if (c_mem.m_mult[0] != g_mem.m_mult[0]){
            // Old m_mult
            g_refNew.pos[0] /= c_mem.m_mult[0];
            // New m_mult
            g_refNew.pos[0] *= g_mem.m_mult[0];
        }
        
        if (c_mem.m_mult[1] != g_mem.m_mult[1]){
            // Old m_mult
            g_refNew.pos[1] /= c_mem.m_mult[1];
            // New m_mult
            g_refNew.pos[1] *= g_mem.m_mult[1];
        }
        
        if (c_mem.m_off[0] != g_mem.m_off[0])
            g_refNew.pos[0] += g_mem.m_off[0] - c_mem.m_off[0];

        if (c_mem.m_off[1] != g_mem.m_off[1])
            g_refNew.pos[1] += g_mem.m_off[1] - c_mem.m_off[1];
            
        // Check position Limits
        if (c_mem.pos_lim_flag) {                   // position limiting
            if (g_refNew.pos[0] < c_mem.pos_lim_inf[0]) g_refNew.pos[0] = c_mem.pos_lim_inf[0];
            if (g_refNew.pos[1] < c_mem.pos_lim_inf[1]) g_refNew.pos[1] = c_mem.pos_lim_inf[1];

            if (g_refNew.pos[0] > c_mem.pos_lim_sup[0]) g_refNew.pos[0] = c_mem.pos_lim_sup[0];
            if (g_refNew.pos[1] > c_mem.pos_lim_sup[1]) g_refNew.pos[1] = c_mem.pos_lim_sup[1];
        }
    }
    
    // Store params 

    if ( memStore(0) ) {
        sendAcknowledgment(ACK_OK);
    } else {
        sendAcknowledgment(ACK_ERROR);
    }
}

void cmd_set_baudrate(){
    
    // Set BaudRate
    c_mem.baud_rate = g_rx.buffer[1];
    
    switch(g_rx.buffer[1]){
        case 13:
            CLOCK_UART_SetDividerValue(13);
            break;
        default:
            CLOCK_UART_SetDividerValue(3);
    }
}

/* [] END OF FILE */